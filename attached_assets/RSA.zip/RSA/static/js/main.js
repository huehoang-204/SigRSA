// Đặt socket ở đầu file để mọi nơi đều dùng được
const socket = io();
let currentRoom = null;
let fileChunks = [];
let currentFile = null;
let totalChunks = 0;
let receivedChunks = 0;
let ipUpdateInterval = null;

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Socket.IO connection event
    socket.on('connect', () => {
        console.log('Connected to server with ID:', socket.id);
        // Get the client's IP address from the server once
        updateMyIp();
        
        // Update IP less frequently (every 30 seconds)
        clearInterval(ipUpdateInterval);
        ipUpdateInterval = setInterval(updateMyIp, 60000); // Increase to 60 seconds to reduce network traffic
        
        // Update status indicator
        const statusIndicator = document.querySelector('.status-indicator');
        if (statusIndicator) {
            statusIndicator.classList.add('online');
            statusIndicator.classList.remove('offline');
            const statusText = statusIndicator.querySelector('.status-text');
            if (statusText) {
                statusText.textContent = 'Đang chờ kết nối...';
            }
        }
    });
    
    // Auto-hide flash messages after 5 seconds
    const flashMessages = document.querySelectorAll('.alert');
    if (flashMessages.length > 0) {
        setTimeout(() => {
            flashMessages.forEach(message => {
                message.style.opacity = '0';
                setTimeout(() => {
                    message.style.display = 'none';
                }, 500);
            });
        }, 5000);
    }
    
    // Thiết lập ngôn ngữ mặc định là tiếng Việt
    document.documentElement.lang = 'vi';
    
    // Các bản dịch tiếng Việt cho các phần tử tĩnh
    const translations = {
        'Secure File Transfer with RSA Digital Signatures': 'Truyền File An Toàn với Chữ Ký Số RSA',
        'Upload a File': 'Tải Lên Tập Tin',
        'Select a file to upload:': 'Chọn tập tin để tải lên:',
        'Upload & Sign': 'Tải Lên & Ký',
        'Verify a File': 'Xác Thực Tập Tin',
        'Select a file to verify:': 'Chọn tập tin để xác thực:',
        'Upload signature file:': 'Tải lên tập tin chữ ký:',
        'Verify': 'Xác Thực',
        'Available Files': 'Tập Tin Có Sẵn',
        'No files available.': 'Không có tập tin nào.',
        'Download File': 'Tải Xuống Tập Tin',
        'Download Signature': 'Tải Xuống Chữ Ký',
        'Public Key': 'Khóa Công Khai',
        'Download the public key to verify files:': 'Tải xuống khóa công khai để xác thực tập tin:',
        'Download Public Key': 'Tải Xuống Khóa Công Khai',
        'Send File': 'Gửi File',
        'Receive File': 'Nhận File',
        'Enter receiver IP address:': 'Nhập địa chỉ IP người nhận:',
        'Connect': 'Kết nối',
        'Waiting for connection...': 'Đang chờ kết nối...',
        'Connected to:': 'Đã kết nối với:',
        'Disconnect': 'Ngắt kết nối',
        'Send': 'Gửi',
        'File Transfer': 'Truyền File',
        'File Reception': 'Nhận File'
    };
    
    // Áp dụng bản dịch cho các phần tử
    document.querySelectorAll('h1, h2, label, button, p, a, span.file-name').forEach(element => {
        const originalText = element.textContent.trim();
        if (translations[originalText]) {
            element.textContent = translations[originalText];
        }
    });
    
    // Chuyển đổi giữa các tab giao diện
    const tabs = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    if (tabs.length > 0) {
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Xóa class active từ tất cả các tab
                tabs.forEach(t => t.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Thêm class active cho tab được chọn
                tab.classList.add('active');
                const targetId = tab.getAttribute('data-target');
                const targetContent = document.getElementById(targetId);
                if (targetContent) {
                    targetContent.classList.add('active');
                    
                    // If switching to the files tab, update the received files list
                    if (targetId === 'files-tab' || targetId === 'receive-tab') {
                        updateReceivedFiles();
                    }
                }
            });
        });
        
        // Mặc định hiển thị tab đầu tiên
        tabs[0].click();
    }
    
    // Hiển thị tên file khi chọn file
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            const fileNameDisplay = this.parentElement.querySelector('.file-name-display');
            
            if (this.files.length > 0) {
                const file = this.files[0];
                // Hiển thị tên file và kích thước
                fileNameDisplay.innerHTML = `
                    <div class="uploaded-file-item">
                        <div class="file-icon">
                            <i class="fas fa-file"></i>
                        </div>
                        <div class="file-details">
                            <div class="file-title">${file.name}</div>
                            <div class="file-meta">${formatFileSize(file.size)} - Đã chọn</div>
                        </div>
                    </div>
                `;
                fileNameDisplay.classList.add('active');
                
                // Enable send button if this is the send file input
                if (this.id === 'send-file-input') {
                    const sendFileBtn = document.getElementById('send-file-btn');
                    if (sendFileBtn) {
                        sendFileBtn.disabled = false;
                    }
                }
            } else {
                fileNameDisplay.textContent = '';
                fileNameDisplay.classList.remove('active');
                
                // Disable send button if this is the send file input
                if (this.id === 'send-file-input') {
                    const sendFileBtn = document.getElementById('send-file-btn');
                    if (sendFileBtn) {
                        sendFileBtn.disabled = true;
                    }
                }
            }
        });
    });
    
    // Connect to receiver
    const connectBtn = document.getElementById('connect-btn');
    if (connectBtn) {
        connectBtn.addEventListener('click', () => {
            const ipInput = document.getElementById('receiver-ip');
            const ip = ipInput.value.trim();
            
            if (ip) {
                // Log the connection attempt
                console.log('Attempting to connect to:', ip);
                
                // Request connection with more detailed logging
                socket.emit('request_connection', { 
                    target_ip: ip,
                    debug_info: true
                });
                
                const connectionStatus = document.getElementById('connection-status');
                if (connectionStatus) {
                    connectionStatus.textContent = 'Đang kết nối...';
                }
            } else {
                alert('Vui lòng nhập địa chỉ IP người nhận');
            }
        });
    }
    
    // Disconnect from receiver
    const disconnectBtn = document.getElementById('disconnect-btn');
    if (disconnectBtn) {
        disconnectBtn.addEventListener('click', () => {
            if (currentRoom) {
                socket.emit('disconnect_room', { room: currentRoom });
                currentRoom = null;
                
                // Update UI
                const connectionStatus = document.getElementById('connection-status');
                if (connectionStatus) {
                    connectionStatus.textContent = 'Chưa kết nối';
                }
                
                // Disable send button
                const sendFileBtn = document.getElementById('send-file-btn');
                if (sendFileBtn) {
                    sendFileBtn.disabled = true;
                }
                
                // Show connect button, hide disconnect button
                const connectBtn = document.getElementById('connect-btn');
                if (connectBtn) {
                    connectBtn.style.display = 'inline-block';
                    disconnectBtn.style.display = 'none';
                }
            }
        });
    }
    
    // Update the send file button handler
    const sendFileBtn = document.getElementById('send-file-btn');
    if (sendFileBtn) {
        // Xóa tất cả event listener hiện có
        const newSendFileBtn = sendFileBtn.cloneNode(true);
        sendFileBtn.parentNode.replaceChild(newSendFileBtn, sendFileBtn);
        
        // Thêm event listener mới
        newSendFileBtn.addEventListener('click', () => {
            const fileInput = document.getElementById('send-file-input');
            console.log("Send file button clicked, currentRoom:", currentRoom);
            
            if (!currentRoom) {
                alert('Vui lòng kết nối với người nhận trước');
                return;
            }
            
            if (fileInput.files.length > 0) {
                const file = fileInput.files[0];
                console.log(`Attempting to send file: ${file.name}, size: ${file.size}, room: ${currentRoom}`);
                
                // Update status
                const transferStatusText = document.getElementById('transfer-status-text');
                if (transferStatusText) {
                    transferStatusText.textContent = `Đang chuẩn bị gửi file: ${file.name}`;
                }
                
                // Send file request to receiver
                socket.emit('send_file_request', {
                    room: currentRoom,
                    filename: file.name,
                    filesize: file.size,
                    sender_id: socket.id
                });
            } else {
                alert('Vui lòng chọn file để gửi');
            }
        });
    }
});

// Socket event handlers (outside of DOMContentLoaded to avoid duplication)
// Handle connection request
socket.on('connection_request', (data) => {
    const fromIp = data.from_ip;
    const room = data.room;
    const fromId = data.from_id;
    
    console.log(`Received connection request from ${fromIp} (${fromId}) for room ${room}`);
    
    // Create notification element if it doesn't exist
    let notification = document.querySelector('.connection-request');
    if (!notification) {
        notification = document.createElement('div');
        notification.className = 'connection-request';
        
        // Create notification content
        notification.innerHTML = `
            <div class="notification-header">
                <i class="fas fa-plug"></i>
                <span>Yêu cầu kết nối mới</span>
            </div>
            <div class="notification-body">
                <p>Yêu cầu kết nối từ: <strong>${fromIp}</strong></p>
                <div class="connection-actions">
                    <button class="btn btn-accept" id="accept-connection">Chấp nhận</button>
                    <button class="btn btn-reject" id="reject-connection">Từ chối</button>
                </div>
            </div>
        `;
        
        // Add notification to the page
        const receiveTab = document.getElementById('receive-tab');
        if (receiveTab) {
            // Insert after the IP display but before the files section
            const ipSection = receiveTab.querySelector('.ip-section') || receiveTab.firstElementChild;
            if (ipSection && ipSection.nextElementSibling) {
                receiveTab.insertBefore(notification, ipSection.nextElementSibling);
            } else {
                receiveTab.appendChild(notification);
            }
        }
        
        // Handle accept button
        const acceptBtn = notification.querySelector('#accept-connection');
        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                socket.emit('accept_connection', { room: room });
                currentRoom = room;
                
                // Update status indicator
                const statusIndicator = document.querySelector('.status-indicator');
                if (statusIndicator) {
                    const statusText = statusIndicator.querySelector('.status-text');
                    if (statusText) {
                        statusText.textContent = `Đã kết nối với: ${fromIp}`;
                    }
                }
                
                // Update connection status
                const connectionStatus = document.querySelector('#receive-tab .connection-status');
                if (connectionStatus) {
                    connectionStatus.textContent = `Đã kết nối với: ${fromIp}`;
                    connectionStatus.classList.add('connected');
                }
                
                // Remove notification
                notification.remove();
            });
        }
        
        // Handle reject button
        const rejectBtn = notification.querySelector('#reject-connection');
        if (rejectBtn) {
            rejectBtn.addEventListener('click', () => {
                socket.emit('reject_connection', { room: room, from_id: fromId });
                notification.remove();
            });
        }
    }
});

// Handle connection accepted
socket.on('connection_accepted', (data) => {
    console.log('Received connection_accepted:', data);
    currentRoom = data.room;
    console.log('Current room set to:', currentRoom);
    
    // Cập nhật trạng thái cho cả bên gửi và bên nhận
    const connectionStatus = document.getElementById('connection-status');
    if (connectionStatus) {
        connectionStatus.textContent = 'Đã kết nối';
    }
    
    // Cập nhật status indicator nếu có
    const statusText = document.querySelector('.status-text');
    if (statusText) {
        // Nếu có thông tin IP đối tác, hiển thị rõ hơn
        if (data.partner_ip) {
            statusText.textContent = `Đã kết nối với: ${data.partner_ip}`;
        } else {
            statusText.textContent = 'Đã kết nối';
        }
    }
    
    // Enable send button nếu là bên gửi
    const sendFileBtn = document.getElementById('send-file-btn');
    if (sendFileBtn) {
        sendFileBtn.disabled = false;
    }
    
    // Show connected UI
    const connectBtn = document.getElementById('connect-btn');
    const disconnectBtn = document.getElementById('disconnect-btn');
    if (connectBtn && disconnectBtn) {
        connectBtn.style.display = 'none';
        disconnectBtn.style.display = 'inline-block';
    }
});

// Handle connection rejected
socket.on('connection_rejected', () => {
    alert('Kết nối bị từ chối');
    const connectionStatus = document.getElementById('connection-status');
    if (connectionStatus) {
        connectionStatus.textContent = 'Kết nối bị từ chối';
    }
});

// Handle connection error
socket.on('connection_error', (data) => {
    alert(data.message);
    const connectionStatus = document.getElementById('connection-status');
    if (connectionStatus) {
        connectionStatus.textContent = data.message;
    }
});

// Handle file request
socket.on('file_request', (data) => {
    console.log('Received file request:', data);
    const filename = data.filename;
    const filesize = data.filesize;
    const senderId = data.sender_id;
    
    // Create file request UI
    const fileItem = document.createElement('div');
    fileItem.className = 'file-item';
    fileItem.innerHTML = `
        <div class="file-info">
            <span class="file-icon">📄</span>
            <span class="file-name">${filename}</span>
            <span class="file-size">${formatFileSize(filesize)}</span>
        </div>
        <div class="progress-container" style="display: none;">
            <div class="progress-bar" style="width: 0%">0%</div>
        </div>
        <div class="file-actions">
            <button class="btn btn-small btn-accept" data-sender="${senderId}">Chấp nhận</button>
            <button class="btn btn-small btn-reject" data-sender="${senderId}">Từ chối</button>
        </div>
    `;
    
    // Remove "no files" message if it exists
    const noFilesMessage = document.querySelector('.incoming-files .no-files-message');
    if (noFilesMessage) {
        noFilesMessage.style.display = 'none';
    }
    
    // Add file item to the list
    const incomingFiles = document.querySelector('.incoming-files');
    if (incomingFiles) {
        incomingFiles.appendChild(fileItem);
    }
    
    // Handle accept button
    fileItem.querySelector('.btn-accept').addEventListener('click', function() {
        const senderId = this.getAttribute('data-sender');
        console.log('Accepting file from sender:', senderId);
        
        socket.emit('accept_file', { 
            sender_id: senderId,
            room: currentRoom // Add room information
        });
        
        // Show progress bar
        const progressContainer = fileItem.querySelector('.progress-container');
        progressContainer.style.display = 'block';
        
        // Hide action buttons
        fileItem.querySelector('.file-actions').style.display = 'none';
        
        // Reset file chunks array
        fileChunks = [];
        currentFile = {
            name: filename,
            size: filesize
        };
        receivedChunks = 0;
    });
    
    // Handle reject button
    fileItem.querySelector('.btn-reject').addEventListener('click', function() {
        const senderId = this.getAttribute('data-sender');
        socket.emit('reject_file', { 
            sender_id: senderId,
            room: currentRoom // Add room information
        });
        fileItem.remove();
        
        // Show "no files" message if no more files
        if (document.querySelectorAll('.file-item').length === 0) {
            if (noFilesMessage) {
                noFilesMessage.style.display = 'block';
            }
        }
    });
});

// Handle start file transfer
socket.on('start_file_transfer', (data) => {
    console.log('Received start_file_transfer event');
    
    // Get the file from input
    const fileInput = document.getElementById('send-file-input');
    if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        const chunkSize = 1024 * 100; // 100KB chunks for faster transfer
        totalChunks = Math.ceil(file.size / chunkSize);
        
        console.log(`Starting file transfer: ${file.name}, size: ${file.size}, chunks: ${totalChunks}`);
        
        // Show progress bar
        const progressContainer = document.querySelector('#send-tab .progress-container');
        const progressBar = document.querySelector('#send-tab .progress-bar');
        if (progressContainer && progressBar) {
            progressContainer.style.display = 'block';
            progressBar.style.width = '0%';
            progressBar.textContent = '0%';
        }
        
        // Inside the start_file_transfer event handler, update this part:
        
        // Add status text element if it doesn't exist
        let transferStatusText = document.getElementById('transfer-status-text');
        if (!transferStatusText) {
            transferStatusText = document.createElement('div');
            transferStatusText.id = 'transfer-status-text';
            transferStatusText.className = 'transfer-status';
            if (progressContainer && progressContainer.parentNode) {
                progressContainer.parentNode.insertBefore(transferStatusText, progressContainer);
            } else {
                // If we can't find the progress container's parent, add it to the send tab
                const sendTab = document.getElementById('send-tab');
                if (sendTab) {
                    const progressSection = document.createElement('div');
                    progressSection.className = 'progress-section';
                    progressSection.appendChild(transferStatusText);
                    
                    if (!progressContainer) {
                        progressContainer = document.createElement('div');
                        progressContainer.className = 'progress-container';
                        progressBar = document.createElement('div');
                        progressBar.className = 'progress-bar';
                        progressBar.style.width = '0%';
                        progressBar.textContent = '0%';
                        progressContainer.appendChild(progressBar);
                    }
                    
                    progressSection.appendChild(progressContainer);
                    sendTab.appendChild(progressSection);
                }
            }
        }
        
        // Make sure the status is visible
        if (transferStatusText) {
            transferStatusText.textContent = `Đang chuẩn bị gửi file: ${file.name}`;
            transferStatusText.style.display = 'block';
            transferStatusText.style.visibility = 'visible';
            
            // Also add file info in a more visible format
            const fileInfoDiv = document.createElement('div');
            fileInfoDiv.className = 'file-transfer-info';
            fileInfoDiv.innerHTML = `
                <p><strong>Tên file:</strong> ${file.name}</p>
                <p><strong>Kích thước:</strong> ${formatFileSize(file.size)}</p>
                <p><strong>Phòng:</strong> ${currentRoom}</p>
            `;
            
            // Insert before the transfer status
            if (transferStatusText.parentNode) {
                transferStatusText.parentNode.insertBefore(fileInfoDiv, transferStatusText);
            }
        }
        
        // Read and send file in chunks
        let chunk = 0;
        const reader = new FileReader();
        
        // Track acknowledged chunks
        const acknowledgedChunks = new Set();
        
        reader.onload = function(e) {
            // Send chunk to server
            socket.emit('file_chunk', {
                room: currentRoom,
                chunk: e.target.result,
                chunk_id: chunk,
                total_chunks: totalChunks,
                filename: file.name
            });
            
            // Update progress based on sent chunks (initial feedback)
            const sentProgress = Math.round(((chunk + 1) / totalChunks) * 100);
            if (progressBar) {
                progressBar.style.width = sentProgress + '%';
                progressBar.textContent = sentProgress + '%';
            }
            
            // Update status text
            if (transferStatusText) {
                transferStatusText.textContent = `Đang gửi file: ${file.name} (${sentProgress}%)`;
            }
            
            // Increment chunk counter for next read
            chunk++;
            
            // Read next chunk or finish
            if (chunk < totalChunks) {
                setTimeout(() => readNextChunk(), 10); // Small delay to prevent UI freezing
            }
        };
        
        function readNextChunk() {
            const start = chunk * chunkSize;
            const end = Math.min(start + chunkSize, file.size);
            reader.readAsDataURL(file.slice(start, end));
        }
        
        // Start reading
        readNextChunk();
        
        // Handle chunk acknowledgment
        // Inside the chunk_received event handler for sender
        socket.on('chunk_received', (data) => {
            acknowledgedChunks.add(data.chunk_id);
            console.log(`Chunk ${data.chunk_id + 1}/${data.total_chunks} acknowledged`);
            
            // Update progress based on acknowledged chunks
            const progress = Math.round((acknowledgedChunks.size / totalChunks) * 100);
            if (progressBar) {
                progressBar.style.width = progress + '%';
                progressBar.textContent = progress + '%';
            }
            
            // Update status text
            if (transferStatusText) {
                transferStatusText.textContent = `Đang gửi file: ${file.name} (${progress}%)`;
            }
            
            // Update sender stats
            updateSenderStats(chunk, totalChunks, acknowledgedChunks.size);
            
            // Log in history
            if (acknowledgedChunks.size % 10 === 0 || acknowledgedChunks.size === 1 || acknowledgedChunks.size === totalChunks) {
                addTransferHistoryItem(true, `Chunk ${acknowledgedChunks.size}/${totalChunks} acknowledged (${progress}%)`);
            }
            
            // If all chunks are acknowledged, we're done
            if (acknowledgedChunks.size === totalChunks) {
                console.log('All chunks acknowledged');
                if (transferStatusText) {
                    transferStatusText.textContent = `Đã gửi file thành công: ${file.name}`;
                }
                addTransferHistoryItem(true, `File transfer completed successfully: ${file.name}`);
                // Clean up the event listener
                socket.off('chunk_received');
            }
        });
    }
});

// Handle file rejected
socket.on('file_rejected', () => {
    alert('Người nhận đã từ chối file');
    // Hide progress bar
    const progressContainer = document.querySelector('#send-tab .progress-container');
    if (progressContainer) {
        progressContainer.style.display = 'none';
    }
});

// Handle receiving file chunks
// Inside the file_chunk event handler for receiver
socket.on('file_chunk', (data) => {
    const chunk = data.chunk;
    const chunkId = data.chunk_id;
    totalChunks = data.total_chunks;
    
    // Store the chunk
    fileChunks[chunkId] = chunk;
    receivedChunks++;
    
    // Update progress
    const progress = Math.round((receivedChunks / totalChunks) * 100);
    const fileItems = document.querySelectorAll('.file-item');
    const fileItem = fileItems[fileItems.length - 1];
    if (fileItem) {
        const progressBar = fileItem.querySelector('.progress-bar');
        if (progressBar) {
            progressBar.style.width = progress + '%';
            progressBar.textContent = progress + '%';
        }
    }
    
    // Update receiver stats
    updateReceiverStats(currentFile.name, currentFile.size, receivedChunks, totalChunks);
    
    // Log progress in history
    if (receivedChunks % 10 === 0 || receivedChunks === 1 || receivedChunks === totalChunks) {
        addTransferHistoryItem(false, `Received chunk ${receivedChunks}/${totalChunks} (${progress}%)`);
    }
    
    // Check for missing chunks if we've received most chunks
    if (receivedChunks > totalChunks * 0.9) {
        for (let i = 0; i < totalChunks; i++) {
            if (!fileChunks[i]) {
                // Request retransmission of missing chunk
                requestChunkRetransmission(i, currentFile.name);
                addTransferHistoryItem(false, `Requested retransmission of chunk ${i+1}`);
            }
        }
    }
    
    // Acknowledge receipt of chunk
    socket.emit('chunk_received', {
        chunk_id: chunkId,
        total_chunks: totalChunks,
        room: currentRoom
    });
});

// Inside the chunk_received event handler for sender
socket.on('chunk_received', (data) => {
    acknowledgedChunks.add(data.chunk_id);
    console.log(`Chunk ${data.chunk_id + 1}/${data.total_chunks} acknowledged`);
    
    // Update progress based on acknowledged chunks
    const progress = Math.round((acknowledgedChunks.size / totalChunks) * 100);
    if (progressBar) {
        progressBar.style.width = progress + '%';
        progressBar.textContent = progress + '%';
    }
    
    // Update status text
    if (transferStatusText) {
        transferStatusText.textContent = `Đang gửi file: ${file.name} (${progress}%)`;
    }
    
    // Update sender stats
    updateSenderStats(chunk, totalChunks, acknowledgedChunks.size);
    
    // Log in history
    if (acknowledgedChunks.size % 10 === 0 || acknowledgedChunks.size === 1 || acknowledgedChunks.size === totalChunks) {
        addTransferHistoryItem(true, `Chunk ${acknowledgedChunks.size}/${totalChunks} acknowledged (${progress}%)`);
    }
    
    // If all chunks are acknowledged, we're done
    if (acknowledgedChunks.size === totalChunks) {
        console.log('All chunks acknowledged');
        if (transferStatusText) {
            transferStatusText.textContent = `Đã gửi file thành công: ${file.name}`;
        }
        addTransferHistoryItem(true, `File transfer completed successfully: ${file.name}`);
        // Clean up the event listener
        socket.off('chunk_received');
    }
});

// Handle file transfer complete
socket.on('file_transfer_complete', (data) => {
    // Combine chunks into a single file
    if (fileChunks.length === totalChunks) {
        try {
            // Process the chunks
            let processedChunks = [];
            for (let i = 0; i < totalChunks; i++) {
                if (i === 0) {
                    // Keep the full data URL for the first chunk
                    processedChunks.push(fileChunks[i]);
                } else {
                    // For subsequent chunks, remove the data URL prefix
                    const parts = fileChunks[i].split(',');
                    processedChunks.push(parts[1]);
                }
            }
            
            // Create a single data URL
            const fullDataURL = processedChunks[0].split(',')[0] + ',' + 
                               processedChunks.map((chunk, index) => 
                                   index === 0 ? chunk.split(',')[1] : chunk).join('');
            
            // Create download link
            const blob = dataURLToBlob(fullDataURL);
            const url = URL.createObjectURL(blob);
            
            // Save the file temporarily to verify signature
            const tempFile = new File([blob], data.filename);
            const formData = new FormData();
            formData.append('file', tempFile);
            formData.append('signature', data.signature);
            
            // Verify the signature
            fetch('/verify_transfer_signature', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(result => {
                if (result.valid) {
                    // Signature is valid, download the file
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = data.filename;
                    a.style.display = 'none';
                    document.body.appendChild(a);
                    a.click();
                    
                    // Clean up
                    setTimeout(() => {
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                    }, 100);
                    
                    // Show success message
                    alert('File đã được nhận thành công và chữ ký số hợp lệ!');
                    
                    // Hiển thị thông báo nhận file thành công
                    showSuccessNotification(`Đã nhận file ${data.filename} thành công!`);
                    
                    // Cập nhật danh sách file đã nhận
                    updateReceivedFiles();
                } else {
                    // Signature is invalid
                    alert('Chữ ký số không hợp lệ! File có thể đã bị sửa đổi.');
                }
                
                // Update UI
                const fileItems = document.querySelectorAll('.file-item');
                const fileItem = fileItems[fileItems.length - 1];
                if (fileItem) {
                    fileItem.remove();
                    
                    // Show "no files" message if no more files
                    if (document.querySelectorAll('.file-item').length === 0) {
                        const noFilesMessage = document.querySelector('.no-files-message');
                        if (noFilesMessage) {
                            noFilesMessage.style.display = 'block';
                        }
                    }
                }
                
                // Reset variables
                fileChunks = [];
                currentFile = null;
                totalChunks = 0;
                receivedChunks = 0;
            })
            .catch(error => {
                console.error('Error verifying signature:', error);
                alert('Có lỗi xảy ra khi xác thực chữ ký số. Vui lòng thử lại.');
            });
        } catch (error) {
            console.error('Error processing file chunks:', error);
            alert('Có lỗi xảy ra khi xử lý file. Vui lòng thử lại.');
        }
    }
});

// Thêm xử lý sự kiện 'disconnected' ở client để reset giao diện khi một bên ngắt kết nối.
socket.on('disconnected', (data) => {
    currentRoom = null;
    // Cập nhật lại giao diện khi ngắt kết nối
    const connectionStatus = document.getElementById('connection-status');
    if (connectionStatus) {
        connectionStatus.textContent = 'Chưa kết nối';
    }
    const statusText = document.querySelector('.status-text');
    if (statusText) {
        statusText.textContent = 'Chưa kết nối';
    }
    const sendFileBtn = document.getElementById('send-file-btn');
    if (sendFileBtn) {
        sendFileBtn.disabled = true;
    }
    const connectBtn = document.getElementById('connect-btn');
    const disconnectBtn = document.getElementById('disconnect-btn');
    if (connectBtn && disconnectBtn) {
        connectBtn.style.display = 'inline-block';
        disconnectBtn.style.display = 'none';
    }
});
function dataURLToBlob(dataURL) {
    const parts = dataURL.split(';base64,');
    const contentType = parts[0].split(':')[1];
    const raw = window.atob(parts[1]);
    const rawLength = raw.length;
    const uInt8Array = new Uint8Array(rawLength);
    
    for (let i = 0; i < rawLength; ++i) {
        uInt8Array[i] = raw.charCodeAt(i);
    }
    
    return new Blob([uInt8Array], { type: contentType });
} // This closing brace was missing
// Utility functions
// Cập nhật IP client
function updateMyIp() {
    fetch('/get_my_ip')
        .then(response => response.json())
        .then(data => {
            const myIp = data.ip;
            console.log('My IP:', myIp);
            
            // Register client with IP
            socket.emit('register_client', {
                username: 'User-' + Math.floor(Math.random() * 1000),
                ip: myIp
            });
            
            // Display IP for easy sharing
            const myIpElement = document.getElementById('my-ip');
            if (myIpElement) {
                myIpElement.textContent = myIp + ':5000';
            }
        })
        .catch(error => {
            console.error('Error getting IP:', error);
        });
}

// Hiển thị thông báo thành công
function showSuccessNotification(message) {
    const flashContainer = document.querySelector('.flash-messages') || createFlashContainer();
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success';
    alertDiv.textContent = message;
    flashContainer.appendChild(alertDiv);
    
    // Tự động ẩn thông báo sau 5 giây
    setTimeout(() => {
        alertDiv.style.opacity = '0';
        setTimeout(() => {
            alertDiv.remove();
        }, 500);
    }, 5000);
}

// Tạo container cho flash messages nếu chưa tồn tại
function createFlashContainer() {
    const container = document.querySelector('.container');
    const flashContainer = document.createElement('div');
    flashContainer.className = 'flash-messages';
    container.insertBefore(flashContainer, container.firstChild.nextSibling);
    return flashContainer;
}

// Add this function to format file sizes
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Add this function to format time
function formatTime(seconds) {
    if (seconds < 60) return `${Math.floor(seconds)} seconds`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${Math.floor(seconds % 60)}s`;
    return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
}

// Add this to update sender transfer stats
function updateSenderStats(sentChunks, totalChunks, acknowledgedChunks) {
    const chunksSentEl = document.getElementById('chunks-sent');
    const totalChunksEl = document.getElementById('total-chunks');
    const chunksAckedEl = document.getElementById('chunks-acked');
    const totalChunksAckEl = document.getElementById('total-chunks-ack');
    const transferRateEl = document.getElementById('transfer-rate');
    const estimatedTimeEl = document.getElementById('estimated-time');
    const transferStats = document.querySelector('.transfer-stats');
    
    if (transferStats) {
        transferStats.style.display = 'grid';
    }
    
    if (chunksSentEl && totalChunksEl) {
        chunksSentEl.textContent = sentChunks;
        totalChunksEl.textContent = totalChunks;
    }
    
    if (chunksAckedEl && totalChunksAckEl) {
        chunksAckedEl.textContent = acknowledgedChunks;
        totalChunksAckEl.textContent = totalChunks;
    }
    
    // Calculate transfer rate and estimated time
    const now = Date.now();
    if (!window.transferStartTime) {
        window.transferStartTime = now;
        window.lastUpdateTime = now;
        window.lastSentChunks = 0;
    }
    
    const elapsedSeconds = (now - window.transferStartTime) / 1000;
    const recentElapsed = (now - window.lastUpdateTime) / 1000;
    
    if (recentElapsed > 1) {
        const chunksSinceLast = sentChunks - window.lastSentChunks;
        const bytesPerSecond = (chunksSinceLast * 1024 * 100) / recentElapsed; // Assuming 100KB chunks
        
        if (transferRateEl) {
            transferRateEl.textContent = `${formatFileSize(bytesPerSecond)}/s`;
        }
        
        // Update estimated time
        if (estimatedTimeEl && sentChunks > 0) {
            const remainingChunks = totalChunks - sentChunks;
            const estimatedSecondsLeft = (remainingChunks / (sentChunks / elapsedSeconds));
            estimatedTimeEl.textContent = formatTime(estimatedSecondsLeft);
        }
        
        window.lastUpdateTime = now;
        window.lastSentChunks = sentChunks;
    }
}

// Add this to update receiver transfer stats
function updateReceiverStats(filename, filesize, receivedChunks, totalChunks) {
    const transferPanel = document.querySelector('.transfer-status-panel');
    const filenameEl = document.getElementById('receiving-filename');
    const filesizeEl = document.getElementById('receiving-filesize');
    const progressEl = document.getElementById('receiving-progress');
    
    if (transferPanel) {
        transferPanel.style.display = 'block';
    }
    
    if (filenameEl) {
        filenameEl.textContent = filename;
    }
    
    if (filesizeEl) {
        filesizeEl.textContent = formatFileSize(filesize);
    }
    
    if (progressEl) {
        const progress = Math.round((receivedChunks / totalChunks) * 100);
        progressEl.textContent = `${progress}%`;
    }
}

// Add this to log transfer history
function addTransferHistoryItem(isSender, message) {
    const listId = isSender ? 'sender-history-list' : 'transfer-history-list';
    const historyList = document.getElementById(listId);
    const historyContainer = isSender ? document.querySelector('.transfer-history-sender') : null;
    
    if (historyContainer) {
        historyContainer.style.display = 'block';
    }
    
    if (historyList) {
        const item = document.createElement('li');
        const timestamp = new Date().toLocaleTimeString();
        item.textContent = `[${timestamp}] ${message}`;
        historyList.appendChild(item);
        historyList.scrollTop = historyList.scrollHeight;
        
        // Limit history items
        while (historyList.children.length > 50) {
            historyList.removeChild(historyList.firstChild);
        }
    }
}