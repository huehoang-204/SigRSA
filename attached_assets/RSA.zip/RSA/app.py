import os
import hashlib
import base64
import json
from flask import Flask, request, render_template, redirect, url_for, send_from_directory, flash, session
from flask_socketio import SocketIO, emit, join_room, leave_room
from werkzeug.utils import secure_filename
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['KEY_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'keys')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

# Initialize SocketIO
socketio = SocketIO(app, cors_allowed_origins="*")

# Create directories if they don't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['KEY_FOLDER'], exist_ok=True)

# Store active connections
active_clients = {}

# Existing functions remain unchanged
def generate_key_pair():
    # Generate RSA key pair
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    
    # Get public key
    public_key = private_key.public_key()
    
    # Serialize private key
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    
    # Serialize public key
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    
    # Save keys to files
    private_key_path = os.path.join(app.config['KEY_FOLDER'], 'private_key.pem')
    public_key_path = os.path.join(app.config['KEY_FOLDER'], 'public_key.pem')
    
    with open(private_key_path, 'wb') as f:
        f.write(private_pem)
    
    with open(public_key_path, 'wb') as f:
        f.write(public_pem)
    
    return private_key_path, public_key_path

def sign_file(file_path, private_key_path):
    # Load private key
    with open(private_key_path, 'rb') as key_file:
        private_key = serialization.load_pem_private_key(
            key_file.read(),
            password=None,
            backend=default_backend()
        )
    
    # Calculate file hash
    file_hash = hashlib.sha256()
    with open(file_path, 'rb') as f:
        while chunk := f.read(8192):
            file_hash.update(chunk)
    
    # Sign the hash
    signature = private_key.sign(
        file_hash.digest(),
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    
    # Return base64 encoded signature
    return base64.b64encode(signature).decode('utf-8')

def verify_signature(file_path, signature, public_key_path):
    # Load public key
    with open(public_key_path, 'rb') as key_file:
        public_key = serialization.load_pem_public_key(
            key_file.read(),
            backend=default_backend()
        )
    
    # Calculate file hash
    file_hash = hashlib.sha256()
    with open(file_path, 'rb') as f:
        while chunk := f.read(8192):
            file_hash.update(chunk)
    
    # Decode signature from base64
    signature_bytes = base64.b64decode(signature)
    
    # Verify the signature
    try:
        public_key.verify(
            signature_bytes,
            file_hash.digest(),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        return True
    except Exception:
        return False

@app.route('/')
def index():
    # Redirect to transfer page by default
    return redirect(url_for('transfer'))

@app.route('/transfer')
def transfer():
    # Generate keys if they don't exist
    private_key_path = os.path.join(app.config['KEY_FOLDER'], 'private_key.pem')
    public_key_path = os.path.join(app.config['KEY_FOLDER'], 'public_key.pem')
    
    if not os.path.exists(private_key_path) or not os.path.exists(public_key_path):
        generate_key_pair()
    
    # Get list of uploaded files
    files = []
    for filename in os.listdir(app.config['UPLOAD_FOLDER']):
        if os.path.isfile(os.path.join(app.config['UPLOAD_FOLDER'], filename)) and not filename.endswith('.sig'):
            files.append(filename)
    
    return render_template('transfer.html', files=files)

# Add a new route for the original index page if you still want to access it
@app.route('/original')
def original_index():
    # Generate keys if they don't exist
    private_key_path = os.path.join(app.config['KEY_FOLDER'], 'private_key.pem')
    public_key_path = os.path.join(app.config['KEY_FOLDER'], 'public_key.pem')
    
    if not os.path.exists(private_key_path) or not os.path.exists(public_key_path):
        generate_key_pair()
    
    # Get list of uploaded files
    files = []
    for filename in os.listdir(app.config['UPLOAD_FOLDER']):
        if os.path.isfile(os.path.join(app.config['UPLOAD_FOLDER'], filename)) and not filename.endswith('.sig'):
            files.append(filename)
    
    return render_template('index.html', files=files)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    
    if file:
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        # Sign the file
        private_key_path = os.path.join(app.config['KEY_FOLDER'], 'private_key.pem')
        signature = sign_file(file_path, private_key_path)
        
        # Save signature to a file
        sig_path = file_path + '.sig'
        with open(sig_path, 'w') as f:
            f.write(signature)
        
        flash(f'File {filename} uploaded and signed successfully')
        return redirect(url_for('transfer'))  # Changed from 'index' to 'transfer'

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/download_signature/<filename>')
def download_signature(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename + '.sig')

@app.route('/verify', methods=['POST'])
def verify_file():
    if 'file' not in request.files or 'signature' not in request.files:
        flash('Missing file or signature')
        return redirect(url_for('transfer'))  # Changed from 'index' to 'transfer'
    
    file = request.files['file']
    signature_file = request.files['signature']
    
    if file.filename == '' or signature_file.filename == '':
        flash('No selected file or signature')
        return redirect(url_for('transfer'))  # Changed from 'index' to 'transfer'
    
    # Save the uploaded file temporarily
    filename = secure_filename(file.filename)
    temp_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_' + filename)
    file.save(temp_file_path)
    
    # Read the signature
    signature = signature_file.read().decode('utf-8')
    
    # Verify the signature
    public_key_path = os.path.join(app.config['KEY_FOLDER'], 'public_key.pem')
    is_valid = verify_signature(temp_file_path, signature, public_key_path)
    
    # Clean up
    os.remove(temp_file_path)
    
    if is_valid:
        flash('Signature is valid! The file is authentic.')
    else:
        flash('Invalid signature! The file may have been tampered with.')
    
    return redirect(url_for('transfer'))  # Changed from 'index' to 'transfer'

@app.route('/download_public_key')
def download_public_key():
    return send_from_directory(app.config['KEY_FOLDER'], 'public_key.pem')

# Remove this duplicate route
# @app.route('/transfer')
# def transfer():
#     # Generate keys if they don't exist
#     private_key_path = os.path.join(app.config['KEY_FOLDER'], 'private_key.pem')
#     public_key_path = os.path.join(app.config['KEY_FOLDER'], 'public_key.pem')
#     
#     if not os.path.exists(private_key_path) or not os.path.exists(public_key_path):
#         generate_key_pair()
#     
#     # Get list of uploaded files
#     files = []
#     for filename in os.listdir(app.config['UPLOAD_FOLDER']):
#         if os.path.isfile(os.path.join(app.config['UPLOAD_FOLDER'], filename)) and not filename.endswith('.sig'):
#             files.append(filename)
#     
#     return render_template('transfer.html', files=files)

# SocketIO event handlers for real-time file transfer
@socketio.on('connect')
def handle_connect():
    client_id = request.sid
    ip = request.remote_addr
    active_clients[client_id] = {'ip': ip}
    print(f"Client connected: {client_id} from {ip}")

@socketio.on('disconnect')
def handle_disconnect():
    client_id = request.sid
    if client_id in active_clients:
        del active_clients[client_id]
    print(f"Client disconnected: {client_id}")

@socketio.on('register_client')
def handle_register(data):
    client_id = request.sid
    # Use the IP from data if provided, otherwise use the one from request
    ip = data.get('ip', request.remote_addr)
    
    # Remove port if included
    if ':' in ip:
        ip = ip.split(':')[0]
        
    active_clients[client_id]['ip'] = ip
    active_clients[client_id]['username'] = data.get('username', 'Anonymous')
    
    print(f"Client registered: {client_id} with IP {ip}")
    
    # Broadcast updated client list to all connected clients
    emit('client_list', list(active_clients.values()), broadcast=True)

# Add these imports
from flask import jsonify
import socket

# Add this route to get the client's IP address
@app.route('/get_my_ip', methods=['GET'])
def get_my_ip():
    # Try to get the real IP address
    if request.environ.get('HTTP_X_FORWARDED_FOR'):
        ip = request.environ['HTTP_X_FORWARDED_FOR'].split(',')[0]
    else:
        ip = request.remote_addr
    
    # If we're getting a loopback address, try to get the actual IP
    if ip == '127.0.0.1' or ip == 'localhost':
        try:
            # Get the hostname
            hostname = socket.gethostname()
            # Get the IP address
            ip = socket.gethostbyname(hostname)
        except Exception as e:
            print(f"Error getting IP: {e}")
    
    return jsonify({'ip': ip})

# Add this route to verify file signatures during transfer
@app.route('/verify_transfer_signature', methods=['POST'])
def verify_transfer_signature():
    if 'file' not in request.files or 'signature' not in request.files:
        return jsonify({'valid': False, 'error': 'Missing file or signature'})
    
    file = request.files['file']
    signature_file = request.files['signature']
    
    if file.filename == '' or signature_file.filename == '':
        return jsonify({'valid': False, 'error': 'No selected file or signature'})
    
    # Save the uploaded file temporarily
    filename = secure_filename(file.filename)
    temp_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_' + filename)
    file.save(temp_file_path)
    
    # Read the signature
    signature = signature_file.read().decode('utf-8')
    
    # Verify the signature
    public_key_path = os.path.join(app.config['KEY_FOLDER'], 'public_key.pem')
    is_valid = verify_signature(temp_file_path, signature, public_key_path)
    
    # Clean up
    os.remove(temp_file_path)
    
    return jsonify({'valid': is_valid})

# Update the SocketIO event handler for connection requests
@socketio.on('request_connection')
def handle_connection_request(data):
    target_ip = data.get('target_ip')
    debug_info = data.get('debug_info', False)
    
    # Remove port number if included in the IP address
    if ':' in target_ip:
        target_ip = target_ip.split(':')[0]
    
    if debug_info:
        print(f"Connection request from {request.sid} to {target_ip}")
        print(f"Active clients: {active_clients}")
    
    # Find the client with the target IP
    target_client = None
    for cid, client in active_clients.items():
        if client.get('ip') == target_ip:
            target_client = cid
            break
    
    if target_client:
        # Create a room for these two clients
        room = f"{request.sid}_{target_client}"
        join_room(room)
        # Ask the target client to join the room
        emit('connection_request', {
            'from_id': request.sid,
            'from_ip': active_clients[request.sid]['ip'],
            'room': room
        }, to=target_client)
    else:
        if debug_info:
            print(f"Target IP {target_ip} not found in active clients")
        emit('connection_error', {'message': f'Không tìm thấy máy nhận với IP {target_ip}'})

# Update the file transfer complete handler to include signature
@socketio.on('file_transfer_complete')
def handle_file_complete(data):
    room = data.get('room')
    filename = data.get('filename')
    
    # If we have a temporary file, sign it
    temp_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_' + filename)
    signature = ""
    
    if os.path.exists(temp_file_path):
        # Sign the file
        private_key_path = os.path.join(app.config['KEY_FOLDER'], 'private_key.pem')
        signature = sign_file(temp_file_path, private_key_path)
        
        # Clean up the temporary file
        os.remove(temp_file_path)
    
    # Notify the receiver that the file transfer is complete
    emit('file_transfer_complete', {
        'filename': filename,
        'signature': signature
    }, to=room)

# Thêm route để lấy danh sách file đã nhận
@app.route('/get_received_files', methods=['GET'])
def get_received_files():
    # Lấy danh sách file từ thư mục uploads
    files = []
    for filename in os.listdir(app.config['UPLOAD_FOLDER']):
        if os.path.isfile(os.path.join(app.config['UPLOAD_FOLDER'], filename)) and not filename.endswith('.sig'):
            files.append(filename)
    
    return jsonify({'files': files})

# Thêm route để tải xuống file
@app.route('/download/<filename>')
def download(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)

# Cập nhật xử lý khi nhận file hoàn tất
# Update the file chunk handler to improve performance
@socketio.on('file_chunk')
def handle_file_chunk(data):
    room = data.get('room')
    filename = data.get('filename')
    chunk = data.get('chunk')
    chunk_id = data.get('chunk_id')  # Use chunk_id instead of current_chunk
    total_chunks = data.get('total_chunks')
    
    print(f"Received chunk {chunk_id+1}/{total_chunks} for file {filename} in room {room}")
    
    # Save chunk to temporary file
    temp_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_' + filename)
    
    try:
        # For the first chunk, create a new file
        if chunk_id == 0:
            with open(temp_file_path, 'wb') as f:
                chunk_data = base64.b64decode(chunk.split(',')[1] if ',' in chunk else chunk)
                f.write(chunk_data)
        else:
            # For subsequent chunks, append to the file
            with open(temp_file_path, 'ab') as f:
                chunk_data = base64.b64decode(chunk.split(',')[1] if ',' in chunk else chunk)
                f.write(chunk_data)
        
        # Send acknowledgment to sender
        emit('chunk_received', {
            'chunk_id': chunk_id,
            'total_chunks': total_chunks
        }, to=room)
        
        # When all chunks are received, process the file
        if chunk_id == total_chunks - 1:
            print(f"All chunks received for {filename}, processing file...")
            # Sign the file
            private_key_path = os.path.join(app.config['KEY_FOLDER'], 'private_key.pem')
            signature = sign_file(temp_file_path, private_key_path)
            
            # Rename the temporary file to its original name
            final_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            os.rename(temp_file_path, final_path)
            
            # Save signature to a file
            sig_path = final_path + '.sig'
            with open(sig_path, 'w') as f:
                f.write(signature)
            
            # Notify both the sender and receiver that the file transfer is complete
            emit('file_transfer_complete', {
                'filename': filename,
                'signature': signature
            }, to=room)
            
            # Notify the receiver that the file has been received successfully
            emit('file_received_success', {
                'filename': filename
            }, to=room)
    except Exception as e:
        print(f"Error processing file chunk: {e}")
        emit('file_transfer_error', {'message': f'Lỗi xử lý file: {str(e)}'}, to=room)

# Thêm route để xóa file
# @app.route('/delete_file/<filename>')
# def delete_file(filename):
#     file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
#     signature_path = file_path + '.sig'
#     # Xóa file gốc nếu tồn tại
#     if os.path.exists(file_path):
#         os.remove(file_path)
#     # Xóa file chữ ký nếu tồn tại
#     if os.path.exists(signature_path):
#         os.remove(signature_path)
#     flash(f'Đã xóa file {filename} thành công')
#     return redirect(url_for('transfer'))

# Chỉ giữ lại 1 route remove_file, xóa/comment đoạn trùng lặp phía dưới
@app.route('/remove_file/<filename>')  # Changed route path
def remove_file(filename):  # Changed function name
    # Same implementation
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    signature_path = file_path + '.sig'
    
    # Xóa file gốc nếu tồn tại
    if os.path.exists(file_path):
        os.remove(file_path)
    
    # Xóa file chữ ký nếu tồn tại
    if os.path.exists(signature_path):
        os.remove(signature_path)
    
    flash(f'Đã xóa file {filename} thành công')
    return redirect(url_for('transfer'))

# Add these debug logs to your socket event handlers

@socketio.on('send_file_request')
def handle_send_file_request(data):
    room = data.get('room')
    filename = data.get('filename')
    filesize = data.get('filesize')
    sender_id = data.get('sender_id', request.sid)
    
    print(f"File request from {sender_id} in room {room}: {filename} ({filesize} bytes)")
    
    # Emit to the other user in the room
    emit('file_request', {
        'filename': filename,
        'filesize': filesize,
        'sender_id': sender_id
    }, room=room, include_self=False)

@socketio.on('accept_file')
def handle_accept_file(data):
    sender_id = data.get('sender_id')
    room = data.get('room')
    
    print(f"File accepted by {request.sid} from {sender_id} in room {room}")
    
    # Emit to the sender
    emit('start_file_transfer', {}, room=sender_id)

@socketio.on('reject_file')
def handle_reject_file(data):
    sender_id = data.get('sender_id')
    
    print(f"File rejected by {request.sid} from {sender_id}")
    
    # Emit to the sender
    emit('file_rejected', {}, room=sender_id)

@socketio.on('accept_connection')
def handle_accept_connection(data):
    room = data.get('room')
    # Make sure we have a valid room
    if not room or '_' not in room:
        print(f"Invalid room format: {room}")
        return
        
    # Get sender and receiver IDs from the room name
    sender_sid = room.split('_')[0]
    receiver_sid = request.sid  # Use the current requester's SID
    
    # Make sure both clients are still connected
    if sender_sid not in active_clients or receiver_sid not in active_clients:
        print(f"One of the clients disconnected: sender={sender_sid in active_clients}, receiver={receiver_sid in active_clients}")
        emit('connection_error', {'message': 'Một trong hai bên đã ngắt kết nối'}, to=request.sid)
        return
    
    # Get IPs for both sides
    sender_ip = active_clients.get(sender_sid, {}).get('ip', '')
    receiver_ip = active_clients.get(receiver_sid, {}).get('ip', '')
    
    print(f"Connection accepted: Room={room}, Sender={sender_sid}({sender_ip}), Receiver={receiver_sid}({receiver_ip})")
    
    # Make sure the receiver joins the room too
    join_room(room)
    
    # Send connection_accepted event to both sides with partner's IP
    emit(
        'connection_accepted',
        {'room': room, 'partner_ip': receiver_ip},
        to=sender_sid
    )
    emit(
        'connection_accepted',
        {'room': room, 'partner_ip': sender_ip},
        to=receiver_sid
    )

# Thêm route để xóa file
# @app.route('/delete_file/<filename>')
# def delete_file(filename):  # Change this function name to something different
#     file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
#     signature_path = file_path + '.sig'
#     
#     # Xóa file gốc nếu tồn tại
#     if os.path.exists(file_path):
#         os.remove(file_path)
#     
#     # Xóa file chữ ký nếu tồn tại
#     if os.path.exists(signature_path):
#         os.remove(signature_path)
#     
#     flash(f'Đã xóa file {filename} thành công')
#     return redirect(url_for('transfer'))

# Change it to something like:
# @app.route('/remove_file/<filename>')  # Changed route path
# def remove_file(filename):  # Changed function name
#     # Same implementation
#     file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
#     signature_path = file_path + '.sig'
#     
#     # Xóa file gốc nếu tồn tại
#     if os.path.exists(file_path):
#         os.remove(file_path)
#     
#     # Xóa file chữ ký nếu tồn tại
#     if os.path.exists(signature_path):
#         os.remove(signature_path)
#     
#     flash(f'Đã xóa file {filename} thành công')
#     return redirect(url_for('transfer'))

# Add these debug logs to your socket event handlers

@socketio.on('send_file_request')
def handle_send_file_request(data):
    room = data.get('room')
    filename = data.get('filename')
    filesize = data.get('filesize')
    sender_id = data.get('sender_id', request.sid)
    
    print(f"File request from {sender_id} in room {room}: {filename} ({filesize} bytes)")
    
    # Emit to the other user in the room
    emit('file_request', {
        'filename': filename,
        'filesize': filesize,
        'sender_id': sender_id
    }, room=room, include_self=False)

@socketio.on('accept_file')
def handle_accept_file(data):
    sender_id = data.get('sender_id')
    room = data.get('room')
    
    print(f"File accepted by {request.sid} from {sender_id} in room {room}")
    
    # Emit to the sender
    emit('start_file_transfer', {}, room=sender_id)

@socketio.on('reject_file')
def handle_reject_file(data):
    sender_id = data.get('sender_id')
    
    print(f"File rejected by {request.sid} from {sender_id}")
    
    # Emit to the sender
    emit('file_rejected', {}, room=sender_id)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True, allow_unsafe_werkzeug=True)